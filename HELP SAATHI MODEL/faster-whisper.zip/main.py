import os
import tempfile

from flask import Flask, request, jsonify
from faster_whisper import WhisperModel

app = Flask(__name__)

model = WhisperModel("large-v3", device="cuda", compute_type="float16")


@app.route("/transcribe", methods=["POST"])
def transcribe():
    if "audio" not in request.files:
        return jsonify({"error": "No audio file provided"}), 400

    audio_file = request.files["audio"]

    with tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(audio_file.filename)[1]) as tmp:
        audio_file.save(tmp.name)
        tmp_path = tmp.name

    try:
        segments, info = model.transcribe(tmp_path, language="ne")
        text = " ".join(segment.text for segment in segments)

        return jsonify({
            "detected_language": info.language,
            "language_probability": info.language_probability,
            "text": text,
        })
    finally:
        os.unlink(tmp_path)


if __name__ == "__main__":
    app.run(host="0.0.0.0", debug=True)